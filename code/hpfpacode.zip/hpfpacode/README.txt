README

Within the appropriate folder are PDF files labeled fixedpoint.pdf, polynomial.pdf, and shooting.pdf which outline the respective code associated with each of these approaches.

If you have any questions or concerns, please do write me at timothy.hubbard@colby.edu.

We ask that if you find this code helpful, you cite the following work:

Hubbard, Timothy P. and Harry J. Paarsch (2014): “On the Numerical Solution of Equilibria in Auction Models with Asymmetries within the Private-Values Paradigm,” Chapter 2 of the Handbook of Computational Economics, Volume 3, edited by Kenneth L. Judd and Karl Schmedders. New York: Elsevier. 