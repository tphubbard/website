% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% investigate whether current iteration has achieved convergence
% conv = -1  invalid solution, has not converged
% conv =  0  valid solution, has not converged
% conv =  1  valid solution, has converged to within tolerance

function conv = converge(bids,ibf,vlow,vhigh,ctol)

p = size(ibf,2);
npts = length(bids);
conv = 0;

% check if ibf solutions "blow up" at any point---really this is the key to
% knowing whether bhigh must be increased or decreased
if (sum(isfinite(ibf)) < npts)
    conv = -1;
    return
end

% check that ibfs are monotonically decreasing (since we're integrating
% backwards
for i=1:p
	if issorted(-ibf(:,i)) ~= 1
		conv = -1;
		return
	end
end

% check if the ibfs are contained on [vlow,vhigh]
if (min(ibf(npts,:)) < vlow) || (max(ibf(1,:)) > vhigh)
	conv = -1;
	return
end

% check if ibfs at vlow are close enough to zero
if (max(abs(ibf(npts,:) - vlow)) < ctol)
	conv = 1;
end