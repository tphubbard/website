% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% conduct error analysis on a bid function approximated by a shooting
% algorithm

function [FOC,relerr] = doerrorshooting(alpha,beta,gamma,vlow,vhigh,bhigh, ...
	sol,tol,lwidth,fsize)

p = length(alpha);

% bids to do error anlysis at
npts = 1000;
b = linspace(bhigh,vlow,npts);
% evaluate ode solution at these bids
ibf = deval(sol,b);
ibf = ibf';

% most likely cannot evaluate near high bid
num_nans = p*npts - sum(sum(isfinite(ibf)));
fprintf('IBFs have %d NaN points (close to high bid) of %d total points\n\n', ...
	num_nans,p*npts)

% compute derivative at bids given approximated ibfs
for i=1:npts
	dibf(i,:) = sysode(b(i),ibf(i,:),alpha,beta,vlow,vhigh);
end

% construct ratio of pdf to cdf
ratio(:,1) = ibf(:,1);
ratio(:,2) = (gamma*ibf(:,2) + ...
	(1 - gamma)*betacdf(ibf(:,2),alpha(2),beta(2)))./ ...
	(gamma*1 + (1 - gamma)*betapdf(ibf(:,2),alpha(2),beta(2)));
ratio = 1./ratio;

% sum of ratio*dibf for all bidders
ratiodibf = ratio.*dibf;
ratiosum = sum(ratiodibf')';

% consider "remainder" in FOCs: in perfect solution these should be zero
for j=1:p
	FOC(:,j) = -1 + (ibf(:,j) - b').*(ratiosum - ratiodibf(:,j));
	FOC(1,j) = vhigh - ibf(1,j);
	FOC(npts,j) = vlow - ibf(npts,j);
	relerr(:,j) = FOC(:,j)./b';
end
figure
set(gcf,'DefaultLineLineWidth',lwidth)
set(gca,'FontSize',fsize)
plot(b,FOC,[vlow bhigh],[0 0])
xlabel('b')
ylabel('FOC(b)')
h = legend(['ODE relative tolerance: ',num2str(tol)], ...
	'Location','SouthWest');
set(h,'Box','off');
set(findobj(h,'type','line'),'visible','off');
axis tight