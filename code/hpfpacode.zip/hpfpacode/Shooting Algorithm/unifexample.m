% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% shooting algorithm for solving for bid functions at asymmetric auction.
% use ode solver to find solution for each guess of high bid

clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters of instance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% beta distribution parameters
alpha = [1 1];
beta = [1 1];
if length(alpha) ~= length(beta)
	error('The vectors of shape parameters must be of the same length')
end
% number of points in grid space
npts = 1000;
% lower bound of valuation support
vlow = 0;
% upper bound of valuation support
vhigh = 1;
% number of players 
p = length(alpha);

% convergence tolerance at vlow
ctol = 1e-5;
tol = 1e-5;
options = odeset('RelTol',tol);

% parameters for figure properties
lwidth = 2;
fsize = 14;
set(0,'defaulttextinterpreter','latex','Defaulttextfontsize',fsize);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% find interval containing the true (unknown) high bid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initial guess of high bid
bhigh = (vhigh + vlow)*2/3;

% evaluate inverse bid functions over [vlow,bhigh]
b = linspace(bhigh,vlow,npts);

% set "initial" (really terminal) condition
initcond = vhigh*ones(size(alpha));

% solve system of differential equations for initial guess
[bids,ibf] = ode45(@sysode,b,initcond,options,alpha,beta,vlow,vhigh);
ctest = converge(bids,ibf,vlow,vhigh,ctol);

h = 0.01;
iter = 0;
itmax = 500;
if ctest >= 0
	% guess was too low: increase it until solution "blows up" 
	while (ctest >= 0) && (iter < itmax)
		lowbnd = bhigh;
        bhigh = (1 + h)*bhigh;
		highbnd = bhigh;
		b = linspace(highbnd,vlow,npts);
		[bids,ibf] = ode45(@sysode,b,initcond,options, ...
			alpha,beta,vlow,vhigh);
		ctest = converge(bids,ibf,vlow,vhigh,ctol);
		iter = iter + 1;
	end
else
	% guess was too high: decrease it until solution no longer "blows up"
	while (ctest < 0) && (iter < itmax)
        highbnd = bhigh;
		bhigh = (1 - h)*bhigh;
		lowbnd = bhigh;
		b = linspace(lowbnd,vlow,npts);
		[bids,ibf] = ode45(@sysode,b,initcond,options, ...
			alpha,beta,vlow,vhigh);
		ctest = converge(bids,ibf,vlow,vhigh,ctol);
		iter = iter + 1;
	end
end
fprintf('Bounds on unknown high bid found: [%.9f,%.9f]\n',lowbnd,highbnd)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% bisection algorithm to converge to true high bid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consider midpoint as new guess
bhigh = (lowbnd + highbnd)/2;
b = linspace(bhigh,vlow,npts);
[bids,ibf] = ode45(@sysode,b,initcond,options,alpha,beta,vlow,vhigh);
ctest = converge(bids,ibf,vlow,vhigh,ctol);

while ctest ~= 1 && iter < itmax
	if ctest < 0
		% if midpoint above high bid, new interval is [lowbnd,bhigh]
        highbnd = bhigh;
        bhigh = (lowbnd + highbnd)/2;
		b = linspace(bhigh,vlow,npts);
		[bids,ibf] = ode45(@sysode,b,initcond,options, ...
			alpha,beta,vlow,vhigh);
	else
		% if midpoint below high bid, new interval is [bhigh,highbnd]
        lowbnd = bhigh;
        bhigh = (lowbnd + highbnd)/2;
		b = linspace(bhigh,vlow,npts);
		[bids,ibf] = ode45(@sysode,b,initcond,options, ...
			alpha,beta,vlow,vhigh);
	end
	ctest = converge(bids,ibf,vlow,vhigh,ctol);
    iter = iter + 1;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% output some results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% print some results about convergence
if ctest ~= 1
    bhigh = lowbnd;
	b = linspace(bhigh,vlow,npts);
	[bids,ibf] = ode45(@sysode,b,initcond,options,alpha,beta,vlow,vhigh);
	fprintf('\nProgram terminated after %i iterations\n',iter)
	for i=1:p
		fprintf('ibf(vlow) for bidder %i: %.9f\n',i,ibf(npts,i))
	end
	fprintf('Try again with guess: bhigh = %.9f\n',bhigh)
else
	fprintf('Unknown high bid found: %.9f\n',bhigh)
	b = linspace(bhigh,vlow,npts);
    [bids,ibf] = ode45(@sysode,b,initcond,options,alpha,beta,vlow,vhigh);
    fprintf('\nConvergence after %i iterations with bhigh = %.9f\n', ...
		iter,bhigh)
    for i=1:p
		fprintf('Error at vlow for bidder %i: %.9f\n',i,ibf(npts,i) - vlow)
    end
end

% final solution for future
sol = ode45(@sysode,b,initcond,options,alpha,beta,vlow,vhigh);

% plot some figures
figure
box on
set(gcf,'DefaultLineLineWidth',lwidth)
set(gca,'FontSize',fsize)
plot(ibf,bids,[vlow vhigh],[vlow vhigh])
xlabel('$\mathbf{v}$')
ylabel('$\mathbf{\sigma(v)}$')
axis([vlow vhigh vlow vhigh])
leg = cellstr('');
for j=1:p
	leg{j} = strcat('$\mathbf{\hat{\sigma}_',num2str(j),'(v)}$');
end
leg{p+1} = '$\mathbf{45^\circ}$ Line';
L = legend(leg{:});
set(L,'Interpreter','latex','Location','NorthWest');
   
% compute bid function
v = linspace(vlow,vhigh,1000);
banaly = v/2;
figure
box on
set(gcf,'DefaultLineLineWidth',lwidth)
set(gca,'FontSize',fsize)
plot(ibf(:,1),bids,'k--',ibf(:,2),bids,'k-.',v,banaly,'k-', ...
	[vlow vhigh],[vlow vhigh],'-k')
xlabel('$\mathbf{v}$')
ylabel('$\mathbf{s}$')
axis([vlow vhigh vlow vhigh])
leg = cellstr('');
for j=1:p
	leg{j} = strcat('$\mathbf{\hat{\sigma}_',num2str(j),'(v)}$');
end
leg{p+1} = '$\mathbf{\sigma(v)}$';
leg{p+2} = '$\mathbf{45^\circ}$ Line';
L = legend(leg{:});
set(L,'Interpreter','latex','Location','NorthWest');

% approximations evaluated at b's associated with vgrid for error analysis
sxint = deval(sol,fliplr(banaly(1:999)));
sxint = horzcat([1; 1],sxint);
sxint = fliplr(sxint);
figure 
plot(v,abs(v - sxint(1,:))./v)

