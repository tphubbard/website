% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% define first-order conditions for inverse bid functions in FPSB auction

function dibf = sysode(b,ibf,alpha,beta,gamma,vlow,vhigh)

p = length(alpha);

ratio(1) = ibf(1);
ratio(2) = (gamma*ibf(2) + ...
	(1 - gamma)*betacdf(ibf(2),alpha(2),beta(2)))./ ...
	(gamma*1 + (1 - gamma)*betapdf(ibf(2),alpha(2),beta(2)));

% express system of ODEs
sumterm = sum(1./(ibf - b));
dibf = zeros(size(ibf));
for i=1:p
	dibf(i) = ratio(i)*(sumterm/(p - 1) - 1/(ibf(i) - b));
end