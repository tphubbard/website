% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% define recursively the derivative of Chebyshev polynomials (of the first
% kind) 

function dT = evalchebypolyderiv(z,n)

m = length(z);

if m < (n + 1)
	error('Polynomial degree exceeds number of Chebyshev nodes')
elseif m == (n + 1)
	fprintf('Algorithm is Chebyshev interpolation\n')
end
T = ones(1,m);
T = [T; z];
dT0 = zeros(1,m);
dT1 = ones(1,m);
dT = [dT0; dT1];
for i=3:n+1
	T(i,:) = 2*z.*T(i-1,:) - T(i-2,:);
	dT(i,:) = 2*T(i-1,:) + 2*z.*dT(i-1,:) - dT(i-2,:);
end