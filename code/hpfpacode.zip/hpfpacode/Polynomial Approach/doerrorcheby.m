% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% conduct error analysis on a bid function approximated by a Chebyshev
% polynomial

function [FOC,relerr] = doerrorcheby(alpha,beta,gamma,vlow,vhigh,a, ...
	bhigh,lwidth,fsize)

[d,p] = size(a);
d = d - 1;

% bids to do error anlysis at
npts = 1000;
b = linspace(vlow,bhigh,npts);

% transform to [-1,1] and evaluate Chebyshev polynomials at these points
z = 2*(b - vlow)./(bhigh - vlow) - 1;
T = evalchebypoly(z,d);
dT = evalchebypolyderiv(z,d);

% construct Chebyshev polynomial approximation
for j=1:p
	for i=1:npts
		aT(:,i) = a(:,j).*T(:,i);
		adT(:,i) = a(:,j).*dT(:,i);
	end
	ibf(:,j) = sum(aT);
	dibf(:,j) = 2/(bhigh - vlow)*sum(adT);
end

% need ratio (as pdf/cdf) times dibf
ratiodibf(:,1) = dibf(:,1)./ibf(:,1);
ratiodibf(:,2) = dibf(:,2).*(gamma*1 + ...
	(1 - gamma)*betapdf(ibf(:,2),alpha(2),beta(2)))./(gamma*ibf(:,2) + ...
	(1 - gamma)*betacdf(ibf(:,2),alpha(2),beta(2)));

% sum of ratio*dibf for all bidders
ratiosum = sum(ratiodibf')';

% consider "remainder" in FOCs: in perfect solution these should be zero
for j=1:p
	FOC(:,j) = -1 + (ibf(:,j) - b').*(ratiosum - ratiodibf(:,j));
	FOC(1,j) = vlow - ibf(1,j);
	FOC(npts,j) = vhigh - ibf(npts,j);
	relerr(:,j) = FOC(:,j)./b';
end
figure
set(gcf,'DefaultLineLineWidth',lwidth)
set(gca,'FontSize',fsize)
plot(b',FOC,[vlow bhigh],[0 0])
xlabel('b')
ylabel('FOC(b)')
h = legend(['Polynomials of degree ',num2str(d)],'Location','SouthWest');
set(h,'Box','off');
set(findobj(h,'type','line'),'visible','off');
axis tight