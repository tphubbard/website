% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% approximate bid function at first-price, sealed-bid auction when bidders
% draw valuations from a Beta distribution (with integer parameters a and
% b).  bid function is approximated by a Chebyshev polynomial, the
% coefficients of which are found using AMPL 

clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters of instance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% degree of each Chebyshev polynomial
d = 3;
% beta distribution parameters
alpha = [1 3];
beta = [1 1];
epsilon = 0.1;
gamma = 0.1;
tau = 0.5;

if length(alpha) ~= length(beta)
	error('The vectors of shape parameters must be of the same length')
end
% lower bound of valuation support
vlow = 0;
% upper bound of valuation support
vhigh = 1;
% number of players 
p = length(alpha);

% number of points in grid space
npts = 500;
% number of points to uses on shape constraints
nconpts = 1000;

% parameters for figure properties
lwidth = 2;
fsize = 14;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% export data to AMPL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen('fpsb_copula.dat', 'w');
fprintf(fid,'# Timothy P. Hubbard\n');
fprintf(fid,'# timothy.hubbard@colby.edu\n\n');
fprintf(fid,'# parameter data file\n');
fprintf(fid,'# values output: %s\n\n',datestr(now));
fprintf(fid,'data;\n\n');
fprintAmplParamCLSU(fid,'d',d);
fprintAmplParamCLSU(fid,'p',p);
fprintAmplParamCLSU(fid,'npts',npts);
fprintAmplParamCLSU(fid,'nconpts',nconpts);
fprintAmplParamCLSU(fid,'pi',pi);
fprintAmplParamCLSU(fid,'vlow',vlow);
fprintAmplParamCLSU(fid,'vhigh',vhigh);
fprintAmplParamCLSU(fid,'alpha',alpha);
fprintAmplParamCLSU(fid,'beta',beta);
fprintAmplParamCLSU(fid,'gamma',gamma);
fprintAmplParamCLSU(fid,'theta',copulaparam('Frank',tau));
% initial guess, if any special one
%fpsbsoln;
%bhigh = 0.5;
if exist('bhigh')
	fprintAmplParamCLSU_initial_guess(fid,'bhigh',bhigh);
end
if exist('a')
	% if last solution is called as guess, and last solution involved
	% higher degree polynomial, this will only take first (d + 1) elements
	if (size(a,1) > d + 1)
		a = a(1:d+1,:);
	end
	fprintAmplParamCLSU_initial_guess(fid,'a',a);
end
fclose(fid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% call AMPL from Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
!myampl fpsb_copula.dr


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input solution and plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fpsbsoln_copula;


% points to evaluate (inverse) bid function at
u = linspace(vlow,bhigh,10000);
z = 2*(u - vlow)./(bhigh - vlow) - 1;
T = evalchebypoly(z,d);

set(0,'defaulttextinterpreter','latex','Defaulttextfontsize',fsize);

% construct Chebyshev polynomial approximation
for j=1:p
	for i=1:length(u)
		aT(:,i) = a(:,j).*T(:,i);
	end
	fhat(:,j) = sum(aT);
end
figure
set(gcf,'DefaultLineLineWidth',lwidth)
set(gca,'FontSize',fsize)
plot(fhat(:,1),u,'k',fhat(:,2),u,'k-.',[0 vhigh],[0 vhigh],'k')
xlabel('$\mathbf{v}$')
ylabel('$\mathbf{s}$')
axis([vlow vhigh vlow vhigh])
L = legend('$\mathbf{\hat{\sigma}_1(v)}$', ...
	'$\mathbf{\hat{\sigma}_2(v)}$');
set(L,'Interpreter','latex','Location','NorthWest')
