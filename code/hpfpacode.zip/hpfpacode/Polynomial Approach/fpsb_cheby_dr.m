% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% approximate bid function at first-price, sealed-bid auction when bidders
% draw valuations from a Beta distribution (with integer parameters a and
% b).  bid function is approximated by a Chebyshev polynomial, the
% coefficients of which are found using AMPL 

clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define parameters of instance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% degree of each Chebyshev polynomial
d = 25;
% beta distribution parameters
alpha = [1 1];
beta = [1 1];
gamma = 0.1;

if length(alpha) ~= length(beta)
	error('The vectors of shape parameters must be of the same length')
end
% lower bound of valuation support
vlow = 0;
% upper bound of valuation support
vhigh = 1;
% number of players 
p = length(alpha);

% number of points in grid space
npts = 40;
% number of points to uses on shape constraints
nconpts = 100;

% parameters for figure properties
lwidth = 2;
fsize = 14;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% export data to AMPL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fid = fopen('fpsb.dat', 'w');
fprintf(fid,'# Timothy P. Hubbard\n');
fprintf(fid,'# timothy.hubbard@colby.edu\n\n');
fprintf(fid,'# parameter data file\n');
fprintf(fid,'# values output: %s\n\n',datestr(now));
fprintf(fid,'data;\n\n');
fprintAmplParamCLSU(fid,'d',d);
fprintAmplParamCLSU(fid,'p',p);
fprintAmplParamCLSU(fid,'npts',npts);
fprintAmplParamCLSU(fid,'nconpts',nconpts);
fprintAmplParamCLSU(fid,'pi',pi);
fprintAmplParamCLSU(fid,'vlow',vlow);
fprintAmplParamCLSU(fid,'vhigh',vhigh);
fprintAmplParamCLSU(fid,'alpha',alpha);
fprintAmplParamCLSU(fid,'beta',beta);
fprintAmplParamCLSU(fid,'gamma',gamma);
% initial guess, if any special one
%fpsbsoln;
bhigh = 0.5;
a(1,1) = 0.5;
a(2,1) = 0.5;
a(2,2) = 0.5;
a(1,2) = 0.5;
if exist('bhigh')
	fprintAmplParamCLSU_initial_guess(fid,'bhigh',bhigh);
end
if exist('a')
	% if last solution is called as guess, and last solution involved
	% higher degree polynomial, this will only take first (d + 1) elements
	if (size(a,1) > d + 1)
		a = a(1:d+1,:);
	end
	fprintAmplParamCLSU_initial_guess(fid,'a',a);
end
fclose(fid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% call AMPL from Matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
!myampl fpsb.dr


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% input solution and plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fpsbsoln;


% points to evaluate (inverse) bid function at
u = linspace(vlow,bhigh,1000);
z = 2*(u - vlow)./(bhigh - vlow) - 1;
T = evalchebypoly(z,d);

set(0,'defaulttextinterpreter','latex','Defaulttextfontsize',fsize);

% construct Chebyshev polynomial approximation
for j=1:p
	for i=1:length(u)
		aT(:,i) = a(:,j).*T(:,i);
	end
	fhat(:,j) = sum(aT);
end
figure
set(gcf,'DefaultLineLineWidth',lwidth)
set(gca,'FontSize',fsize)
plot(fhat(:,1),u,'k',fhat(:,2),u,'k-.',[0 vhigh],[0 vhigh],'k')
xlabel('$\mathbf{v}$')
ylabel('$\mathbf{s}$')
axis([vlow vhigh vlow vhigh])
L = legend('$\mathbf{\hat{\sigma}_1(v)}$', ...
	'$\mathbf{\hat{\sigma}_2(v)}$');
set(L,'Interpreter','latex','Location','NorthWest')

[foc,relerr] = doerrorcheby(alpha,beta,gamma,vlow,vhigh,a, ...
	bhigh,lwidth,fsize);
foc = [foc(:,1); foc(:,2)];
meanerr = mean(abs(foc));
stderr = std(abs(foc));
minerr = min(abs(foc));
maxerr = max(abs(foc));

% if valuation distributions are the same for all players, can compute
% analytic bid functions to compare to approximated bid functions
if (length(unique(alpha)) == 1) & (length(unique(beta)) == 1)
	v = linspace(0,1,100);
	Fv = betacdf(v,alpha(1),beta(1));
	Fvlow = betacdf(vlow,alpha(1),beta(1));
	Fvhigh = betacdf(vhigh,alpha(1),beta(1));
	Fv = (Fv - Fvlow)./(Fvhigh - Fvlow);
	% integral portion of symmetric bid function
	for i=1:length(v)
		Q(i) = quad(@risam_quad,vlow,v(i),1e-8,[],alpha(1),beta(1),p, ...
			vlow,vhigh);
	end    
    % compute bid function
    b = v - Q./Fv.^(p - 1);
	figure
	set(gcf,'DefaultLineLineWidth',lwidth)
	set(gca,'FontSize',fsize)
	plot(fhat,u,v,b,[vlow vhigh],[vlow vhigh])
	xlabel('v')
	ylabel('b')
	axis([vlow vhigh vlow vhigh])
	leg = cellstr('');
	for j=1:p
		leg{j} = strcat('\approx Beta_',num2str(j),'(v)');
	end
	leg{p+1} = 'Beta(v)';
	leg{p+2} = '45^o Line';
	legend(leg{:},'Location','NorthWest')
end