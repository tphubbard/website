% Timothy P. Hubbard
% timothy.hubbard@colby.edu

% function to evaluate the integral portion of the analytic, symmetric case
% using Simpson's rule

function y = risam_quad(x,alpha,beta,p,vlow,vhigh)

Fv = betacdf(x,alpha,beta);
Fvlow = betacdf(vlow,alpha,beta);
Fvhigh = betacdf(vhigh,alpha,beta);
Fv = (Fv - Fvlow)./(Fvhigh - Fvlow);

y = Fv.^(p - 1);