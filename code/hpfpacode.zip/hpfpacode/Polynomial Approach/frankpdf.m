function c = frankpdf(u,v,alpha)


num = exp(-alpha*u).*exp(-alpha*v).*(exp(-alpha) - 1);
denom = ((exp(-alpha) - 1) + (exp(-alpha*u) - 1).*(exp(-alpha*v) - 1)).^2;
c = -alpha*num./denom;