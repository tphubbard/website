# Timothy P. Hubbard
# timothy.hubbard@colby.edu

# model file to approximate bid functions at a FPSB auction 
# with Chebyshev polynomials

# this file is for the case in which bidders draw valuations 
# from a Beta distribution in an APVP environment when the joint
# distribution is characterized by a Frank copula

# parameters of model
param d > 0, integer;               # degree of Chebyshev polynomials
param p > 0, integer;               # number of players
param npts > 0, integer;            # number of points in bid grid space
param nconpts > 0, integer;         # number of points to impose constraints on
param pi > 3.14;                    # approximate value for pi
param vlow >= 0;                    # lower bound on valuation support
param vhigh >= vlow;                # upper bound on valuation support
param alpha {1..p} > 0, integer;    # beta distribution shape parameters
param beta {1..p} > 0, integer;     # beta distribution shape parameters
param gamma >= 0;                   # weight on mixture distribution
param theta > 0;                    # Frank copula parameter

# Gamma function at key values
param Gamma_a {j in 1..p} := prod {i in 1..(alpha[j]-1)} i;
param Gamma_b {j in 1..p} := prod {i in 1..(beta[j]-1)} i;
param Gamma_ab {j in 1..p} := prod {i in 1..(alpha[j]+beta[j]-1)} i;
# Beta function given parameters
param Beta  {j in 1..p} := (Gamma_a[j]*Gamma_b[j])/Gamma_ab[j];

# unknowns: the polynomial coefficients and the lowest bid
var a {0..d,1..p} := 0.1;
var bhigh >= vlow, <= vhigh, := (vhigh + vlow)/2;

# find Chebyshev nodes
param z {i in 1..npts} :=
    -cos((2*i - 1)/(2*npts)*pi);
# adjust these to [vlow,bhigh]
var b {i in 1..npts} =
    (z[i] + 1)*(bhigh - vlow)/2 + vlow;
# uniform grid from [vlow,bhigh] for points used in shape constraints
param zcon {i in 1..nconpts} :=
    #(i - 1)/nconpts - 1;
    2*i/nconpts - 1;
# adjust these to [vlow,bhigh]
var bcon {i in 1..nconpts} =
    (zcon[i] + 1)*(bhigh - vlow)/2 + vlow;

# evaluate first d degrees of Chebyshev polynomials at each point
var T {k in 0..d, i in 1..npts} =
    if k = 0
        then 1
    else if k = 1
        then z[i]
    else 
        2*z[i]*T[k-1,i] - T[k-2,i];
# evaluate first d degrees of derivative of Chebyshev polynomials at each point
var dT {k in 0..d, i in 1..npts} =
    if k = 0
        then 0
    else if k = 1
        then 1
    else
        2*T[k-1,i] + 2*z[i]*dT[k-1,i] - dT[k-2,i];
param Tcon {k in 0..d, i in 1..nconpts} :=
        if k = 0
        then 1
    else if k = 1
        then zcon[i]
    else 
        2*zcon[i]*Tcon[k-1,i] - Tcon[k-2,i];
        
# inverse bid function and derivative of ibf at each "bid"
var ibf {i in 1..npts,j in 1..p} =
    sum {k in 0..d} a[k,j]*T[k,i];
var dibf {i in 1..npts,j in 1..p} =
    2/(bhigh - vlow)*sum {k in 0..d} a[k,j]*dT[k,i];
var ibfcon {i in 1..nconpts,j in 1..p} =
    sum {k in 0..d} a[k,j]*Tcon[k,i];
    
# regularized incomplete beta function
var Ixab {i in 1..npts,j in 1..p} =
    (prod {m in 1..(alpha[j]+beta[j]-1)} m)*(sum {l in alpha[j]..(alpha[j]+beta[j]-1)} 
        (ibf[i,j]^l*(1 - ibf[i,j])^(alpha[j] + beta[j] - 1 - l))/((prod {s in 1..l} s)*(prod {t in 1..(alpha[j]+beta[j]-1-l)} t)));
# evaluate cdf at bounds of support for truncation
param Ixab_vlow {j in 1..p} :=
    (prod {m in 1..(alpha[j]+beta[j]-1)} m)*(sum {l in alpha[j]..(alpha[j]+beta[j]-1)} 
        (vlow^l*(1 - vlow)^(alpha[j] + beta[j] - 1 - l))/((prod {s in 1..l} s)*(prod {t in 1..(alpha[j]+beta[j]-1-l)} t)));
param Ixab_vhigh {j in 1..p} :=
    (prod {m in 1..(alpha[j]+beta[j]-1)} m)*(sum {l in alpha[j]..(alpha[j]+beta[j]-1)} 
        (vhigh^l*(1 - vhigh)^(alpha[j] + beta[j] - 1 - l))/((prod {s in 1..l} s)*(prod {t in 1..(alpha[j]+beta[j]-1-l)} t)));
# cdf of Beta distribution
var cdf {i in 1..npts,j in 1..p} =
    (Ixab[i,j] - Ixab_vlow[j])/(Ixab_vhigh[j] - Ixab_vlow[j]);
# pdf of Beta distribution
var trpdf {i in 1..npts,j in 1..p} =
    ((ibf[i,j]^(alpha[j] - 1)*(1 - ibf[i,j])^(beta[j] - 1))/Beta[j])/(Ixab_vhigh[j] - Ixab_vlow[j]);
var pdf {i in 1..npts,j in 1..p} =
    if (alpha[j] = 1 and beta[j] = 1) then 1
    else trpdf[i,j];
    
# uniform mixture distributions
var mixcdf {i in 1..npts,j in 1..p} =
    gamma*ibf[i,j] + (1 - gamma)*cdf[i,j];
var mixpdf {i in 1..npts,j in 1..p} =
    gamma*1 + (1 - gamma)*pdf[i,j];

# ratio of second partial to first partial for Frank copula
var lambda {i in 1..npts} =
    -theta*(exp(-theta) - 1)/((exp(-theta) - 1) + prod {j in 1..p} (exp(-theta*mixcdf[i,j]) - 1));    
var copratio {i in 1..npts,j in 1..p} =
    lambda[i]*exp(-theta*mixcdf[i,2])/(exp(-theta*mixcdf[i,2]) - 1);

# pdf divided by cdf for each player at each bid
var ratio {i in 1..npts,j in 1..p} = 
    mixpdf[i,j]*copratio[i,j];

# first-order conditions for each player
var FOC {i in 1..npts,j in 1..p} =
    -1 + (ibf[i,j] - b[i])*(-ratio[i,j]*dibf[i,j] + sum {l in 1..p} ratio[i,l]*dibf[i,l]);
    
# polynomial needs to be evaluated at specific points for
# conditions on (inverse) bid functions
param zlow := -1;
param Tlow {i in 0..d} =
    if i = 0
        then 1
    else if i = 1
        then zlow
    else 
        2*zlow*Tlow[i-1] - Tlow[i-2];
param dTlow {k in 0..d} =
    if k = 0
        then 0
    else if k = 1
        then 1
    else
        2*Tlow[k-1] + 2*zlow*dTlow[k-1] - dTlow[k-2];
param zhigh := 1;
param Thigh {i in 0..d} =
    if i = 0
        then 1
    else if i = 1
        then zhigh
    else 
        2*zhigh*Thigh[i-1] - Thigh[i-2];
param dThigh {k in 0..d} =
    if k = 0
        then 0
    else if k = 1
        then 1
    else
        2*Thigh[k-1] + 2*zhigh*dThigh[k-1] - dThigh[k-2];
var dibfhigh {j in 1..p} =
    2/(bhigh - vlow)*sum {k in 0..d} a[k,j]*dThigh[k];
var dibflow {j in 1..p} =
    2/(bhigh - vlow)*sum {k in 0..d} a[k,j]*dTlow[k];

        
# minimize FOCs choosing polynomial coefficients
minimize sumofsquares:
    (sum {i in 1..npts,j in 1..p} FOC[i,j]^2)/(p*npts);

# require players to bid vlow if they draw the low valuation
subject to LowCond {j in 1..p}:
    sum {k in 0..d} a[k,j]*Tlow[k] = vlow;
# require players to bid bhigh if they have high valuation
subject to HighCond {j in 1..p}: 
    sum {k in 0..d} a[k,j]*Thigh[k] = vhigh;
# require monotonicity; to make higher bids you need higher valuations
subject to Monotone {i in 2..nconpts,j in 1..p}: 
        ibfcon[i,j] >= ibfcon[i-1,j];
# players must bid less than their valuations
subject to Rational {i in 1..nconpts,j in 1..p}:
        bcon[i] <= ibfcon[i,p];
# must lie in range
subject to Support {i in 1..nconpts,j in 1..p}:
        vlow <= ibfcon[i,p];
