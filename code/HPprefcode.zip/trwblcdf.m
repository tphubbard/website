% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% compute truncated exponential cdf

function trcdf = trwblcdf(x,a,b,xlow,xhigh)

Fx = wblcdf(x,a,b);
Fxlow = wblcdf(xlow,a,b);
Fxhigh = wblcdf(xhigh,a,b);
denom = Fxhigh - Fxlow;
trcdf = (Fx - Fxlow)./denom;