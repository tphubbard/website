% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% compute truncated normal pdf

function trpdf = trnormpdf(x,mu,sigma,xlow,xhigh)

fx = normpdf(x,mu,sigma);
Fxlow = normcdf(xlow,mu,sigma);
Fxhigh = normcdf(xhigh,mu,sigma);
denom = Fxhigh - Fxlow;
trpdf = fx./denom;