% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% plot bid functions using estimated polynomial coefficients

function [b, ibf] = plotbfcheby_ecost(polynp,polyp,blow,noprefcstar, ...
    prefcstar,rho)

global ind f clow chigh pceil

% parameters of the model
nfirm = f;
ngrid = 1000;

% create grid spaces to evaluate ibfs
bnp = linspace(blow,chigh,ngrid)';
bp = linspace(blow*(1 + rho),chigh,ngrid)';
if (isequal(ind,'uniform') == 1)
    bnp = linspace(blow,pceil,ngrid)';
    bp = linspace(blow*(1 + rho),pceil,ngrid)';
end

% compute inverse bid function for each firm at each bid
ibfnp = invbidcheby(bnp,polynp,blow,chigh,rho);
ibfp = invbidcheby(bp,polyp,blow,chigh,rho);

% plot bid functions
figure
set(gcf,'DefaultLineLineWidth',1)
set(gca,'FontSize',14)
plot(ibfp,bp,'-.',ibfnp,bnp,':',[clow chigh],[clow chigh],'k')
legend('Pref \beta_1(c)','Nonpref \beta_2(c)','45^o Line',4)
xlabel('Cost for firm i')
ylabel('Bid for firm i')
xlim([clow chigh])
ylim([clow chigh])
text(3.2,2.2,['\rho = ',num2str(rho*100),' %'],'FontSize',14)

b = [bnp; bp];
ibf = [ibfnp; ibfp];