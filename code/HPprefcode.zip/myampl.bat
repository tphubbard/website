set path=%path%;C:\Program Files\amplcmpl
ampl %1
