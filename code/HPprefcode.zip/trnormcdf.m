% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% compute truncated normal cdf

function trcdf = trnormcdf(x,mu,sigma,xlow,xhigh)

Fx = normcdf(x,mu,sigma);
Fxlow = normcdf(xlow,mu,sigma);
Fxhigh = normcdf(xhigh,mu,sigma);
denom = Fxhigh - Fxlow;
trcdf = (Fx - Fxlow)./denom;