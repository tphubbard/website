% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% evaluate inverse bid function using Chebyshev polynomials

function c = invbidcheby(bid,beta,blow,chigh,rho)

ncoef = length(beta);
degree = ncoef - 1;

[nr,nc] = size(bid);
if nc > nr
    bid = bid';
end

% convert bids from [blow,chigh] to [-1,1]
y = bid - blow;
up = max(bid) - blow;
down = min(bid) - blow;
x = (2*y - down - up)./(up - down);

% evaluate Chebyshev polynomials at relevant points
for i=1:ncoef
    if i == 1
        T(:,i) = ones(length(x),1);
    elseif i == 2
        T(:,i) = x;
    else
        T(:,i) = 2*x.*T(:,i-1) - T(:,i-2);
    end
end

% calculate value of ibf
c = blow;
for i=1:ncoef
    c = c + beta(i)*T(:,i);
end