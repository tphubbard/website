# � 2009 Timothy P. Hubbard
# timothy-hubbard@uiowa.edu

# approximate bid functions using polynomial and use
# nonlinear equation solver to select coefficients and
# endogenous variables using MPEC approach. code set for
# normal distribution - note that since AMPL does not 
# have a function to evaluate the normal cdf we 
# approximate it with an erf (error function) expansion

# parameters of model
param ncoefp > 0, integer;  # number of coefs in preferred polynomial
param ncoefnp > 0, integer; # number of coefs in nonpreferred polynomial
param npts > 0, integer;    # number of bid grid space points
param pi > 3;               # approximate value for pi
param z > 0, integer;       # degree of erf expansion
param clow >= 0, integer;   # lowest possible cost
param chigh > 0, integer;   # highest possilbe cost
param sigma > 0;            # std dev of truncated distributions
param mu {1..2} > 0;        # mean of distributions
param pid;                  # indicator of firm receiving preference
param npid;                 # indicator of firm receiving no preference

# preference auction parameters
param f > 0, integer;       # number of types of firms
param nnp > 0, integer;     # number nonpreferred players
param np > 0, integer;      # number preferrred players
param rho >= 0;             # bid preference rate 

# characteristics of problem
param dp := ncoefp - 1;     # degree of polynomial used
param dnp := ncoefnp - 1;   # degree of polynomial used

# set of players (types of different players)
set P := 1..f;

# construct erf combinatorial and denominator terms
param comb {i in 1..z} :=
        if i < 3
        then  1
        else (i-1)*comb[i-1];
param term {i in 1..z} :=
        2*(i-1) + 1;
param denom {i in 1..z} :=
        comb[i]*term[i];
        
# evaluate erf at chigh and clow
param ch {i in P} :=
    (chigh - mu[i])/(sigma*sqrt(2));
param cl {i in P} :=
    (clow - mu[i])/(sigma*sqrt(2));
param erfh {i in P} :=
    2/sqrt(pi)*(sum {k in 1..z} (-1)^(k - 1)*ch[i]^(2*(k-1) + 1)/denom[k]);
param erfl {i in P} := 
    2/sqrt(pi)*(sum {k in 1..z} (-1)^(k - 1)*cl[i]^(2*(k-1) + 1)/denom[k]);

# evaluate cdfs at truncation points
param hicdf {i in P} :=
    .5*(1 + erfh[i]);
param lowcdf {i in P} :=
    .5*(1 + erfl[i]);

# coefficients of polynomials and endogenous variables
var polyp {1..ncoefp};
var polynp {1..ncoefnp};
var blow;
var bswitch;

# highest/lowest points each polynomial needs to be evaluated at
var downnp = blow - blow;
var upnp = chigh/(1 + rho) - blow;
var downp = blow*(1 + rho) - blow;
var upp = chigh - blow;

###################################################################
# step 1: compute nonpreferred players' FOC
###################################################################
# grid for bids at which nonpreferred polynomial will be evaluated
# these are Cheby points on the interval [blow,chigh/(1 + rho)]
var bgridnp {i in 1..npts} =
    (chigh/(1 + rho) + blow)/2 + (chigh/(1 + rho) - blow)/2*cos((npts - i + 1/2)*pi/npts);
# define points to evaluate polynomials at as (bgrid - blow)
var ynp {j in 1..npts} =
    (bgridnp[j] - blow);
# transform this so points (and future transformations) lie on [-1,1]
var xnp {j in 1..npts} =     
    (2*ynp[j] - downnp - upnp)/(upnp - downnp);

# evaluate first d degrees of Chebyshev polynomials at each x
var Tnp {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xnp[j]
    else 
        2*xnp[j]*Tnp[i-1,j] - Tnp[i-2,j];
# evaluate first d degrees of Chebyshev polynomials (of the
# second kind - so differntiation is easy) at each x
var Unp {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xnp[j]
    else 
        2*xnp[j]*Unp[i-1,j] - Unp[i-2,j];
# evaluate derivative of Chebyshev polynomials at each x
var dTnp {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Unp[i-1,j];

# inverse bid function and derivative of ibf at a particular bid
var ibfnp {j in 1..npts} =
    blow + sum {k in 0..dnp} polynp[k+1]*Tnp[k,j];
var dibfnp {j in 1..npts} =
    (2/(upnp - downnp))*sum {k in 0..dnp} polynp[k+1]*dTnp[k,j];

# evaluate erf at grid points
var hnp {j in 1..npts} =
    (ibfnp[j] - mu[npid])/(sigma*sqrt(2));
var erfnp {j in 1..npts} =
    2/sqrt(pi)*(sum {k in 1..z} (-1)^(k - 1)*hnp[j]^(2*(k-1) + 1)/denom[k]);
# evaluate normal pdf and cdf at ibf for each firm at each bid
var npdfnp {j in 1..npts} =
    1/(sigma*sqrt(2*pi))*exp(-(ibfnp[j] - mu[npid])^2/(2*sigma^2));
var ncdfnp {j in 1..npts} =
    .5*(1 + erfnp[j]);
# evaluate truncated pdfs and cdfs
var trnpdfnp {j in 1..npts} =
    if ibfnp[j] < clow 
        then 0
    else if ibfnp[j] > chigh 
        then 0
    else
        npdfnp[j]/(hicdf[npid] - lowcdf[npid]);
var trncdfnp {j in 1..npts} =
    (ncdfnp[j] - lowcdf[npid])/(hicdf[npid] - lowcdf[npid]);
# get hazard rate
var haznp {j in 1..npts} = 
    trnpdfnp[j]/(1 - trncdfnp[j]);

# profit
var profnp {j in 1..npts} = 
    (bgridnp[j] - ibfnp[j]);

# the nonpreferred players' FOC requires the preferred player's bid function
# to be evaluated at the inflated bids b*(1+rho) so we repeat everything
# above using preferred players' polynomial evaluated at b*(1+rho), note that
# must account for the fact that preferred bidders (when np > 1) will never
# bid more than s/chigh (the seller's reserve/ceiling price) though
var binc {j in 1..npts} = bgridnp[j]*(1 + rho);
var yinc {j in 1..npts} =
    if binc[j] > chigh
        then (chigh - blow)
    else (binc[j] - blow);
var xinc {j in 1..npts} =
    (2*yinc[j] - downp - upp)/(upp - downp);
var Tinc {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xinc[j]
    else 
        2*xinc[j]*Tinc[i-1,j] - Tinc[i-2,j];
var Uinc {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xinc[j]
    else 
        2*xinc[j]*Uinc[i-1,j] - Uinc[i-2,j];
var dTinc {i in 0..dp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Uinc[i-1,j];
var inc_ibf {j in 1..npts} =
    blow + sum {k in 0..dp} polyp[k+1]*Tinc[k,j];
var inc_dibf {j in 1..npts} =
    (2/(upp - downp))*sum {k in 0..dp} polyp[k+1]*dTinc[k,j];
var ih {j in 1..npts} =
    (inc_ibf[j] - mu[pid])/(sigma*sqrt(2));
var ierf {j in 1..npts} =
    2/sqrt(pi)*(sum {k in 1..z} (-1)^(k - 1)*ih[j]^(2*(k-1) + 1)/denom[k]);
var inpdf {j in 1..npts} =
    1/(sigma*sqrt(2*pi))*exp(-(inc_ibf[j] - mu[pid])^2/(2*sigma^2));
var incdf {j in 1..npts} =
    .5*(1 + ierf[j]);
var inc_trnpdf {j in 1..npts} =
     inpdf[j]/(hicdf[pid] - lowcdf[pid]);
var inc_trncdf {j in 1..npts} =
    (incdf[j] - lowcdf[pid])/(hicdf[pid] - lowcdf[pid]);
var inc_haz {j in 1..npts} = 
    inc_trnpdf[j]/(1 - inc_trncdf[j]);

# finally can write down nonpreferred players' foc
var FOCnp {j in 1..npts} =
    1 - profnp[j]*(np*(1+rho)*inc_haz[j]*inc_dibf[j] + (nnp-1)*haznp[j]*dibfnp[j]);

###################################################################
# step 2: compute preferred players' FOC 
###################################################################
# grid for bids at which preferred polynomial will be evaluated
# these are Cheby points on the interval [blow*(1+rho),chigh]
var bgridp {i in 1..npts} =
    (chigh + blow*(1 +rho))/2 + (chigh - blow*(1 + rho))/2*cos((npts - i + 1/2)*pi/npts);
# define points to evaluate polynomials at as (bgrid - blow)
var yp {j in 1..npts} =
    (bgridp[j] - blow);
# transform this so points (and future transformations) lie on [-1,1]
var xp {j in 1..npts} =     
    (2*yp[j] - downp - upp)/(upp - downp);

# evaluate first d degrees of Chebyshev polynomials at each x
var Tp {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xp[j]
    else 
        2*xp[j]*Tp[i-1,j] - Tp[i-2,j];
# evaluate first d degrees of Chebyshev polynomials (of the
# second kind - so differntiation is easy) at each x
var Up {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xp[j]
    else 
        2*xp[j]*Up[i-1,j] - Up[i-2,j];
# evaluate derivative of Chebyshev polynomials at each x
var dTp {i in 0..dp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Up[i-1,j];

# inverse bid function and derivative of ibf at a particular bid
var ibfp {j in 1..npts} =
    blow + sum {k in 0..dp} polyp[k+1]*Tp[k,j];
var dibfp {j in 1..npts} =
    (2/(upp - downp))*sum {k in 0..dp} polyp[k+1]*dTp[k,j];

# evaluate erf at grid points
var hp {j in 1..npts} =
    (ibfp[j] - mu[pid])/(sigma*sqrt(2));
var erfp {j in 1..npts} =
    2/sqrt(pi)*(sum {k in 1..z} (-1)^(k - 1)*hp[j]^(2*(k-1) + 1)/denom[k]);
# evaluate normal pdf and cdf at ibf for each firm at each bid
var npdfp {j in 1..npts} =
    1/(sigma*sqrt(2*pi))*exp(-(ibfp[j] - mu[pid])^2/(2*sigma^2));
var ncdfp {j in 1..npts} =
    .5*(1 + erfp[j]);
# evaluate truncated pdfs and cdfs
var trnpdfp {j in 1..npts} =
    if ibfp[j] < clow 
        then 0
    else if ibfp[j] > chigh 
        then 0
    else
        npdfp[j]/(hicdf[pid] - lowcdf[pid]);
var trncdfp {j in 1..npts} =
    (ncdfp[j] - lowcdf[pid])/(hicdf[pid] - lowcdf[pid]);
# get hazard rate   
var hazp {j in 1..npts} = 
    trnpdfp[j]/(1 - trncdfp[j]);

# profit
var profp {j in 1..npts} = 
    (bgridp[j] - ibfp[j]);

# the preferred players' FOC requires the nonpreferred player's bid function
# to be evaluated at the discounted bids b/(1+rho) so I need to repeat everything
# above using nonpreferred players' polynomial evaluated at b/(1+rho)
var bdisc {j in 1..npts} = bgridp[j]/(1 + rho);
var ydisc {j in 1..npts} =
    (bdisc[j] - blow);
var xdisc {j in 1..npts} =     
    (2*ydisc[j] - downnp - upnp)/(upnp - downnp);
var Tdisc {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xdisc[j]
    else 
        2*xdisc[j]*Tdisc[i-1,j] - Tdisc[i-2,j];
var Udisc {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xdisc[j]
    else 
        2*xdisc[j]*Udisc[i-1,j] - Udisc[i-2,j];
var dTdisc {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Udisc[i-1,j];
var disc_ibf {j in 1..npts} =
    blow + sum {k in 0..dnp} polynp[k+1]*Tdisc[k,j];
var disc_dibf {j in 1..npts} =
    (2/(upnp - downnp))*sum {k in 0..dnp} polynp[k+1]*dTdisc[k,j];
var dh {j in 1..npts} =
    (disc_ibf[j] - mu[npid])/(sigma*sqrt(2));
var derf {j in 1..npts} =
    2/sqrt(pi)*(sum {k in 1..z} (-1)^(k - 1)*dh[j]^(2*(k-1) + 1)/denom[k]);
var dnpdf {j in 1..npts} =
    1/(sigma*sqrt(2*pi))*exp(-(disc_ibf[j] - mu[npid])^2/(2*sigma^2));
var dncdf {j in 1..npts} =
    .5*(1 + derf[j]);
var disc_trnpdf {j in 1..npts} =
     dnpdf[j]/(hicdf[npid] - lowcdf[npid]);
var disc_trncdf {j in 1..npts} =
    (dncdf[j] - lowcdf[npid])/(hicdf[npid] - lowcdf[npid]);
var disc_haz {j in 1..npts} = 
    disc_trnpdf[j]/(1 - disc_trncdf[j]);

# finally can write down preferred players' foc
var FOCp {j in 1..npts} =
    1 - profp[j]*((np-1)*hazp[j]*dibfp[j] + (nnp/(1+rho))*disc_haz[j]*disc_dibf[j]);

###################################################################
# step 3: polynomials evaluated for boundary conditions
###################################################################        
# nonpreferred polynomial at low bid
var xlowNP = (2*(blow - blow) - downnp - upnp)/(upnp - downnp);
var TlowNP {i in 0..dnp} =
    if i = 0
        then 1
    else if i = 1
        then xlowNP
    else 
        2*xlowNP*TlowNP[i-1] - TlowNP[i-2];
# nonpreferred polynomial at chigh/(1 + rho)
var xhighNP = (2*(chigh/(1 + rho) - blow) - downnp - upnp)/(upnp - downnp);
var ThiNP {i in 0..dnp} =
    if i = 0
        then 1
    else if i = 1
        then xhighNP
    else 
        2*xhighNP*ThiNP[i-1] - ThiNP[i-2];
# preferred polynomial at low blow*(1 + rho)
var xlowP = (2*(blow*(1 + rho) - blow) - downp - upp)/(upp - downp);
var TlowP {i in 0..dp} =
    if i = 0
        then 1
    else if i = 1
        then xlowP
    else 
        2*xlowP*TlowP[i-1] - TlowP[i-2];
# preferred polynomial at high bid
var xhiP = (2*(chigh - blow) - downp - upp)/(upp - downp);
var ThiP {i in 0..dp} =
    if i = 0
        then 1
    else if i = 1
        then xhiP
    else 
        2*xhiP*ThiP[i-1] - ThiP[i-2];

###################################################################
# step 4: write down constrained optimization problem
###################################################################        
# minimize FOCs choosing polynomial coefficients
minimize sumofsquares:
    ((sum {j in 1..npts} FOCnp[j]^2) + (sum {i in 1..npts} FOCp[i]^2))/npts;

# require monotonicity; to make higher bids you need higher costs
subject to Monotone1 {j in 2..npts}: 
        ibfnp[j] >= ibfnp[j-1];
subject to Monotone2 {j in 2..npts}: 
        ibfp[j] >= ibfp[j-1];
# players must bid higher than their cost
subject to Rational1 {j in 1..npts}:
        bgridnp[j] >= ibfnp[j];
subject to Rational2 {j in 1..npts}:
        bgridp[j] >= ibfp[j];
# require nonpreferred players to make the low bid if they draw the low cost
subject to LowCondNP:
    blow + sum {k in 0..dnp} polynp[k+1]*TlowNP[k] = clow;
# require nonpreferred players to bid chigh/(1+rho) if they get that cost
subject to HighCondNP: 
    blow + sum {k in 0..dnp} polynp[k+1]*ThiNP[k] = chigh/(1 + rho);
# require preferred players to bid (1+rho)*blow if they draw the low cost
subject to LowCondP:
    blow + sum {k in 0..dp} polyp[k+1]*TlowP[k] = clow;
# require preferred players to bid chigh if they get the high cost
subject to HighCondP: 
    blow + sum {k in 0..dp} polyp[k+1]*ThiP[k] = chigh;
