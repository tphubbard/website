% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% compute truncated Weibull pdf

function trpdf = trwblpdf(x,a,b,xlow,xhigh)

fx = wblpdf(x,a,b);
Fxlow = wblcdf(xlow,a,b);
Fxhigh = wblcdf(xhigh,a,b);
denom = Fxhigh - Fxlow;
trpdf = fx./denom;