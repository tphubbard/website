% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% compute truncated exponential cdf

function trcdf = trexpcdf(x,lambda,xlow,xhigh)

mu = 1./lambda;
Fx = expcdf(x,mu);
Fxlow = expcdf(xlow,mu);
Fxhigh = expcdf(xhigh,mu);
denom = Fxhigh - Fxlow;
trcdf = (Fx - Fxlow)./denom;