% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% approximate bid functions at asymmetric auction with bid preferences when
% there is no entry cost using Chebyshev polynomials, the optimal
% coefficients to which are found my accessing SNOPT solver through AMPL. 

clear all
clc

global ind f clow chigh pceil mu sigma lambda npref nnonpref pid npid

% family of distributions for bidders' costs
ind = 'exponential';
rho = .1;

% define parameter values for instance
ncoefnp = 6;
ncoefp = ncoefnp;
npts = 70;
f = 2;
npref = 2;
nnonpref = 3;
pid = 1;
npid = 2;
z = 18;
pival = pi;

% cost parameters assumed
clow = 1;
chigh = 4;
pceil = 3.99;
sigma = .5;
cmid = (chigh + clow)/2;
mu = [cmid cmid];
lambda = [0.716375266635688 0.716375266635688];
wbla = 3.83851020008437;
wblb = 4;

% export data to AMPL
if (isequal(ind,'normal') == 1)
    fid = fopen('ibf_cheby_noecost_norm.dat','w');
elseif (isequal(ind,'exponential') == 1)
    fid = fopen('ibf_cheby_noecost_exp.dat','w');
elseif (isequal(ind,'uniform') == 1)
    fid = fopen('ibf_cheby_noecost_unif.dat','w');
elseif (isequal(ind,'weibull') == 1)
    fid = fopen('ibf_cheby_noecost_wbl.dat','w');
end
fprintf(fid,'# � 2009 Timothy P. Hubbard\n');
fprintf(fid,'# timothy-hubbard@uiowa.edu\n\n');
fprintf(fid,'# parameter data file\n');
fprintf(fid,'# values output: %s\n\n',datestr(now));
fprintf(fid,'data;\n\n');
fprintAmplParamCLSU(fid,'ncoefnp',ncoefnp);
fprintAmplParamCLSU(fid,'ncoefp',ncoefp);
fprintAmplParamCLSU(fid,'npts',npts);
fprintAmplParamCLSU(fid,'f',f);
fprintAmplParamCLSU(fid,'clow',clow);
fprintAmplParamCLSU(fid,'chigh',chigh);
fprintAmplParamCLSU(fid,'pi',pival);
fprintAmplParamCLSU(fid,'rho',rho);
fprintAmplParamCLSU(fid,'np',npref);
fprintAmplParamCLSU(fid,'nnp',nnonpref);
fprintAmplParamCLSU(fid,'pid',pid);
fprintAmplParamCLSU(fid,'npid',npid);
if (isequal(ind,'normal') == 1)
    fprintAmplParamCLSU(fid,'z',z);
    fprintAmplParamCLSU(fid,'sigma',sigma);
    fprintAmplParamCLSU(fid,'mu',mu);
elseif (isequal(ind,'exponential') == 1)
    fprintAmplParamCLSU(fid,'lambda',lambda);
elseif (isequal(ind,'uniform') == 1)
elseif (isequal(ind,'weibull') == 1)
    fprintAmplParamCLSU(fid,'wbla',wbla);
    fprintAmplParamCLSU(fid,'wblb',wblb);
end
% print initial guess for coefficients if given
if exist('polynp') == 1
    for i=1:ncoefnp
        fprintf(fid,'let polynp[%i] := %.8f;\n',i,polynp(i));
    end
    for i=1:ncoefp
        fprintf(fid,'let polyp[%i] := %.8f;\n',i,polyp(i));
    end
    fprintf(fid,'let blow := %.8f;\n',blow);
end
fclose(fid);

% call AMPL to solve problem
if (isequal(ind,'normal') == 1)
    !myampl ibf_cheby_noecost_norm.dr
    info = csvread('info_noecost_norm.out');
    results_noecost_norm;
elseif (isequal(ind,'exponential') == 1)
    !myampl ibf_cheby_noecost_exp.dr
    info = csvread('info_noecost_exp.out');
    results_noecost_exp;
elseif (isequal(ind,'uniform') == 1)
    !myampl ibf_cheby_noecost_unif.dr
    info = csvread('info_noecost_unif.out');
    results_noecost_unif;
elseif (isequal(ind,'weibull') == 1)
    !myampl ibf_cheby_noecost_wbl.dr
    info = csvread('info_noecost_wbl.out');
    results_noecost_wbl;
end
converge = info(1);
solvetime = info(2);

blow

% if convergence then plot bid functions, otherwise notify user
if converge == 1 
    [b,ibf] = plotbfcheby_noecost(polyp,polynp,blow,rho);
else
    fprintf('\n\nNo optimal solution found\n\n')
end