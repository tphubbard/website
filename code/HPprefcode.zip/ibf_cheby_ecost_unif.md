# � 2009 Timothy P. Hubbard
# timothy-hubbard@uiowa.edu

# approximate bid functions using polynomial and use
# nonlinear equation solver to select coefficients and
# endogenous variables using MPEC approach. code set for
# uniform distribution with a positive entry cost.
# thus, need to solve for: polynomial coefficients, 
# low bid, entry thresholds for each class of bidders

# parameters of model
param npts > 0, integer;    # number of bid grid space points
param pi > 3;               # approximate value for pi
param clow >= 0, integer;   # lowest possible cost
param chigh > 0, integer;   # highest possilbe cost
param pid;                  # indicator of firm receiving preference
param npid;                 # indicator of firm receiving no preference
param ncoefnp > 0, integer; # number of coefs for nonpreferred ibf
param ncoefp > 0, integer;  # number of coefs for preferred ibf

param s := chigh - .01;     # seller reservation/ceiling price
param ecost >= 0;           # entry cost

# preference auction parameters
param f > 0, integer;       # number of types of firms
param nnp > 0, integer;     # number nonpreferred players
param np > 0, integer;      # number preferrred players
param rho >= 0;             # bid preference rate 

# degree of polynomial and highest dibf exponents
param dnp := ncoefnp - 1;
param dp := ncoefp - 1;

# set of players (types of different players)
set P := 1..f;

# beta is coefficients of polynomials we want to find
var polynp {1..ncoefnp};
var polyp {1..ncoefp};
var blow;
var prefcstar;
var noprefcstar;

# highest/lowest points each polynomial needs to be evaluated at
var downnp = blow - blow;
var upnp = s - blow;
var downp = blow*(1 + rho) - blow;
var upp = s - blow;

###################################################################
# step 1: compute nonpreferred players' FOC
###################################################################
# grid for bids at which nonpreferred polynomial will be evaluated
# these are Cheby points on the interval [blow,s]
var bgridnp {i in 1..npts} =
    (s + blow)/2 + (s - blow)/2*cos((npts - i + 1/2)*pi/npts);
# define points to evaluate polynomials at as (bgrid - blow)
var ynp {j in 1..npts} =
    (bgridnp[j] - blow);
# transform this so points (and future transformations) lie on [-1,1]
var xnp {j in 1..npts} =     
    (2*ynp[j] - downnp - upnp)/(upnp - downnp);

# evaluate first d degrees of Chebyshev polynomials at each x
var Tnp {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xnp[j]
    else 
        2*xnp[j]*Tnp[i-1,j] - Tnp[i-2,j];
# evaluate first d degrees of Chebyshev polynomials (of the
# second kind - so differntiation is easy) at each x
var Unp {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xnp[j]
    else 
        2*xnp[j]*Unp[i-1,j] - Unp[i-2,j];
# evaluate derivative of Chebyshev polynomials at each x
var dTnp {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Unp[i-1,j];

# inverse bid function and derivative of ibf at a particular bid
var ibfnp {j in 1..npts} =
    blow + sum {k in 0..dnp} polynp[k+1]*Tnp[k,j];
var dibfnp {j in 1..npts} =
    (2/(upnp - downnp))*sum {k in 0..dnp} polynp[k+1]*dTnp[k,j];

# get hazard rate   
var trnpdfnp {j in 1..npts} =
    if ibfnp[j] < clow
        then 0
    else if ibfnp[j] > chigh
        then 0
    else
        1/(chigh - clow);
var trncdfnp {j in 1..npts} =
    if ibfnp[j] < clow
        then 0
    else if ibfnp[j] > chigh
        then 1
    else
        (ibfnp[j] - clow)/(chigh - clow); 
var haznp {j in 1..npts} = 
    trnpdfnp[j]/(1 - trncdfnp[j]);

# profit
var profnp {j in 1..npts} = 
    (bgridnp[j] - ibfnp[j]);

# the nonpreferred players' FOC requires the preferred player's bid function
# to be evaluated at the inflated bids b*(1+rho) so I need to repeat everything
# above using preferred players' polynomial evaluated at b*(1+rho), note that
# must account for the fact that preferred bidders (when np > 1) will never
# bid more than s/chigh (the seller's reserve/ceiling price) though
var binc {j in 1..npts} = bgridnp[j]*(1 + rho);
var yinc {j in 1..npts} =
    if binc[j] > s
        then (s - blow)
    else (binc[j] - blow);
var xinc {j in 1..npts} =
    (2*yinc[j] - downp - upp)/(upp - downp);
var Tinc {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xinc[j]
    else 
        2*xinc[j]*Tinc[i-1,j] - Tinc[i-2,j];
var Uinc {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xinc[j]
    else 
        2*xinc[j]*Uinc[i-1,j] - Uinc[i-2,j];
var dTinc {i in 0..dp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Uinc[i-1,j];
var inc_ibf {j in 1..npts} =
    blow + sum {k in 0..dp} polyp[k+1]*Tinc[k,j];
var inc_dibf {j in 1..npts} =
    (2/(upp - downp))*sum {k in 0..dp} polyp[k+1]*dTinc[k,j];
var inc_trnpdf {j in 1..npts} =
    if inc_ibf[j] < clow
        then 0
    else if inc_ibf[j] > chigh
        then 0
    else
        1/(chigh - clow);
var inc_trncdf {j in 1..npts} =
    if inc_ibf[j] < clow
        then 0
    else if inc_ibf[j] > chigh
        then 1
    else
        (inc_ibf[j] - clow)/(chigh - clow); 
var inc_haz {j in 1..npts} = 
    inc_trnpdf[j]/(1 - inc_trncdf[j]);

# finally can write down nonpreferred players' foc
var FOCnp {j in 1..npts} =
    1 - profnp[j]*(np*(1+rho)*inc_haz[j]*inc_dibf[j] + (nnp-1)*haznp[j]*dibfnp[j]);

###################################################################
# step 2: compute preferred players' FOC 
###################################################################
# grid for bids at which preferred polynomial will be evaluated
# these are Cheby points on the interval [blow*(1+rho),s]
var bgridp {i in 1..npts} =
    (s + blow*(1 +rho))/2 + (s - blow*(1 + rho))/2*cos((npts - i + 1/2)*pi/npts);
# define points to evaluate polynomials at as (bgrid - blow)
var yp {j in 1..npts} =
    (bgridp[j] - blow);
# transform this so points (and future transformations) lie on [-1,1]
var xp {j in 1..npts} =     
    (2*yp[j] - downp - upp)/(upp - downp);

# evaluate first d degrees of Chebyshev polynomials at each x
var Tp {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xp[j]
    else 
        2*xp[j]*Tp[i-1,j] - Tp[i-2,j];
# evaluate first d degrees of Chebyshev polynomials (of the
# second kind - so differntiation is easy) at each x
var Up {i in 0..dp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xp[j]
    else 
        2*xp[j]*Up[i-1,j] - Up[i-2,j];
# evaluate derivative of Chebyshev polynomials at each x
var dTp {i in 0..dp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Up[i-1,j];

# inverse bid function and derivative of ibf at a particular bid
var ibfp {j in 1..npts} =
    blow + sum {k in 0..dp} polyp[k+1]*Tp[k,j];
var dibfp {j in 1..npts} =
    (2/(upp - downp))*sum {k in 0..dp} polyp[k+1]*dTp[k,j];

# get hazard rate 
var trnpdfp {j in 1..npts} =
    if ibfp[j] < clow
        then 0
    else if ibfp[j] > chigh
        then 0
    else
        1/(chigh - clow);
var trncdfp {j in 1..npts} =
    if ibfp[j] < clow
        then 0
    else if ibfp[j] > chigh
        then 1
    else
        (ibfp[j] - clow)/(chigh - clow);  
var hazp {j in 1..npts} = 
    trnpdfp[j]/(1 - trncdfp[j]);

# profit
var profp {j in 1..npts} = 
    (bgridp[j] - ibfp[j]);

# the preferred players' FOC requires the nonpreferred player's bid function
# to be evaluated at the discounted bids b/(1+rho) so I need to repeat everything
# above using nonpreferred players' polynomial evaluated at b/(1+rho)
var bdisc {j in 1..npts} = bgridp[j]/(1 + rho);
var ydisc {j in 1..npts} =
    (bdisc[j] - blow);
var xdisc {j in 1..npts} =     
    (2*ydisc[j] - downnp - upnp)/(upnp - downnp);
var Tdisc {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then xdisc[j]
    else 
        2*xdisc[j]*Tdisc[i-1,j] - Tdisc[i-2,j];
var Udisc {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 1
    else if i = 1
        then 2*xdisc[j]
    else 
        2*xdisc[j]*Udisc[i-1,j] - Udisc[i-2,j];
var dTdisc {i in 0..dnp, j in 1..npts} =
    if i = 0
        then 0
    else
        i*Udisc[i-1,j];
var disc_ibf {j in 1..npts} =
    blow + sum {k in 0..dnp} polynp[k+1]*Tdisc[k,j];
var disc_dibf {j in 1..npts} =
    (2/(upnp - downnp))*sum {k in 0..dnp} polynp[k+1]*dTdisc[k,j];
var disc_trnpdf {j in 1..npts} =
    if disc_ibf[j] < clow
        then 0
    else if disc_ibf[j] > chigh
        then 0
    else
        1/(chigh - clow);
var disc_trncdf {j in 1..npts} =
    if disc_ibf[j] < clow
        then 0
    else if disc_ibf[j] > chigh
        then 1
    else
        (disc_ibf[j] - clow)/(chigh - clow);  
var disc_haz {j in 1..npts} = 
    disc_trnpdf[j]/(1 - disc_trncdf[j]);

# finally can write down preferred players' foc
var FOCp {j in 1..npts} =
    1 - profp[j]*((np-1)*hazp[j]*dibfp[j] + (nnp/(1+rho))*disc_haz[j]*disc_dibf[j]);

###################################################################
# step 3: compute some other things needed for the entry conditions
###################################################################
# this is the nonpreferred players' ibf evaluated at the discounted highest bid
# s/(1+rho), which is needed for the preferred players' entry condition
var xentry = (2*(s/(1 + rho) - blow) - downnp - upnp)/(upnp - downnp);
var Tentry {i in 0..dnp} =
    if i = 0
        then 1
    else if i = 1
        then xentry
    else 
        2*xentry*Tentry[i-1] - Tentry[i-2];
var noprefentry = 
    if rho > 0
        then blow + sum {k in 0..dnp} polynp[k+1]*Tentry[k]
    else noprefcstar;

# cdfs evaluated at these points
var prefcstarcdf =
    (prefcstar - clow)/(chigh - clow);
var noprefcstarcdf =
    (noprefcstar - clow)/(chigh - clow);
var noprefentrycdf =
    (noprefentry - clow)/(chigh - clow);
    
###################################################################
# step 4: polynomials evaluated for boundary conditions
###################################################################        
# nonpreferred polynomial at low bid
var xlowNP = (2*(blow - blow) - downnp - upnp)/(upnp - downnp);
var TlowNP {i in 0..dnp} =
    if i = 0
        then 1
    else if i = 1
        then xlowNP
    else 
        2*xlowNP*TlowNP[i-1] - TlowNP[i-2];
# nonpreferred polynomial at chigh (or s)
var xhighNP = (2*(s - blow) - downnp - upnp)/(upnp - downnp);
var ThiNP {i in 0..dnp} =
    if i = 0
        then 1
    else if i = 1
        then xhighNP
    else 
        2*xhighNP*ThiNP[i-1] - ThiNP[i-2];
# preferred polynomial at blow*(1 + rho)
var xlowP = (2*(blow*(1 + rho) - blow) - downp - upp)/(upp - downp);
var TlowP {i in 0..dp} =
    if i = 0
        then 1
    else if i = 1
        then xlowP
    else 
        2*xlowP*TlowP[i-1] - TlowP[i-2];
# preferred polynomial at chigh (or s)
var xhiP = (2*(s - blow) - downp - upp)/(upp - downp);
var ThiP {i in 0..dp} =
    if i = 0
        then 1
    else if i = 1
        then xhiP
    else 
        2*xhiP*ThiP[i-1] - ThiP[i-2];
    
###################################################################
# step 5: write down constrained optimization problem
###################################################################        
# minimize FOCs choosing polynomial coefficients
minimize sumofsquares:
    ((sum {j in 1..npts} FOCnp[j]^2) + (sum {i in 1..npts} FOCp[i]^2))/npts;

# require monotonicity; to make higher bids you need higher costs
subject to Monotone1 {j in 2..npts}: 
        ibfnp[j] >= ibfnp[j-1];
subject to Monotone2 {j in 2..npts}: 
        ibfp[j] >= ibfp[j-1];
# players must bid higher than their cost
subject to Rational1 {j in 1..npts}:
        bgridnp[j] >= ibfnp[j];
subject to Rational2 {j in 1..npts}:
        bgridp[j] >= ibfp[j];
# require nonpreferred players to make the low bid if they draw the low cost
subject to LowCondNP:
    blow + sum {k in 0..dnp} polynp[k+1]*TlowNP[k] = clow;
# require nonpreferred players to bid (reservation) price ceiling if they have high cost
subject to HighCondNP: 
    blow + sum {k in 0..dnp} polynp[k+1]*ThiNP[k] = noprefcstar;
# require preferred players to bid (1+rho)*blow if they draw the low cost
subject to LowCondP:
    blow + sum {k in 0..dp} polyp[k+1]*TlowP[k] = clow;
# require preferred players to bid (reservation) price ceiling if they have high cost
subject to HighCondP: 
    blow + sum {k in 0..dp} polyp[k+1]*ThiP[k] = prefcstar;
# entry condition defining threshold cost for preferred bidders
subject to EntryPref:
    (s - prefcstar)*(1 - prefcstarcdf)^(np-1)*(1 - noprefentrycdf)^nnp = ecost;
# entry condition defining threshold cost for nonpreferred bidders
subject to EntryNoPref:
    (s - noprefcstar)*(1 - prefcstarcdf)^np*(1 - noprefcstarcdf)^(nnp-1) = ecost;
