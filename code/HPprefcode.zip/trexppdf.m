% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% compute truncated exponential pdf

function trpdf = trexppdf(x,lambda,xlow,xhigh)

mu = 1./lambda;
fx = exppdf(x,mu);
Fxlow = expcdf(xlow,mu);
Fxhigh = expcdf(xhigh,mu);
denom = Fxhigh - Fxlow;
trpdf = fx./denom;