% � 2009 Timothy P. Hubbard
% timothy-hubbard@uiowa.edu

% plot bid functions using the output from the NEOS server

clear all
clc

global ind f clow chigh pceil

% family of distributions for bidders' costs
ind = 'normal';

% define parameter values for instance
f = 2;
ecost = 0.2;
rho = .1;

% cost parameters assumed
clow = 1;
chigh = 4;
pceil = 3.99;

% paste approximated solution from NEOS server here


if (exist('prefcstar') == 1)
    [b,ibf] = plotbfcheby_ecost(polynp,polyp,blow,noprefcstar, ...
        prefcstar,rho);
else
    [b,ibf] = plotbfcheby_noecost(polyp,polynp,blow,rho);
end